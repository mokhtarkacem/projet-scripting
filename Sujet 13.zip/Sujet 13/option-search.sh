function option-search() {
	sudo apt list > output.txt
	grep -w $1 output.txt
}
