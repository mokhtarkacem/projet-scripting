function option-clean() {
	sudo apt-get clean;
}
