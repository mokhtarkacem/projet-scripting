function option-h() {
echo "PKGScript

[-version][-v][-help][-h][-up] [-clean][-search][-verify]"
echo -e "\n${YELLOW} -up:     ${NC} Mettre à Jour Tous les Paquets du Système."
echo -e "${YELLOW} -clean:  ${NC} Nettoyer le Cache du Gestionnaire de Paquets."
echo -e "${YELLOW} -search: ${NC} Vérifier l'Existance d'un Paquet ( Internet )."
echo -e "${YELLOW} -verify: ${NC} Vérifier l'Existance d'un Paquet Localement."
echo -e "${YELLOW} -v: ${NC} Version."

}
