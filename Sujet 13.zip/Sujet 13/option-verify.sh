function option-verify() {
	sudo apt-cache pkgnames > output.txt
	grep -w $1 output.txt
}
