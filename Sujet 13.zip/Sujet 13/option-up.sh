function option-up() {
	sudo apt-get update;
}
